#include<stdio.h>
int main()
{
    int l =12, b=7;
    printf("Area of rectangle is : %d",l*b);
    printf("\n perimeter of rectangle is : %d", 2 * (l + b));

    return 0;
}