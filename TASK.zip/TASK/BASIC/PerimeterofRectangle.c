#include <stdio.h>

int main()
{

	int l = 10, b = 10;
	printf("Area of rectangle is : %d", l * b);
	printf("\nPerimeter of rectangle is : %d", 2 * (l + b));
	return 0;
}
