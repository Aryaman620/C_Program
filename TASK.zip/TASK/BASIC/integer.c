#include <stdio.h>
int main()
{
	int x = 5;
	printf("Printing Integer value %d", x);
	return 0;
}
