#include<stdio.h>
int  main()
{
    int a = 3;
    printf("Enter the the integer value %d",a);

    return 0;
}