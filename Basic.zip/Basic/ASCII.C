#include<stdio.h>
int main()
{
    char f = 'r';
    printf("The  ASCII value of %c is %d",f,f);

    return 0;

}