#include <stdio.h>
int main() {
    printf("SATYA");
    return 0;
}