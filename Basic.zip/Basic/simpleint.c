#include<stdio.h>
int main()
{
    float p = 1, r = 1, t =1;

    float si = (p*t*r)/100;

    printf("simple interest = %f\n", si);

    return 0;
}